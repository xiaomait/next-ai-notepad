export type NoteType = {
	id: number
	title: string
	content: string
	userId: string
	createdAt: any
	updatedAt: any
}
